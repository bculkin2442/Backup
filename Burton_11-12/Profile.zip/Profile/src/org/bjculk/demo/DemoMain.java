/**
 * 
 */
package org.bjculk.demo;

import javax.swing.JApplet;
//import javax.swing.JLabel;
import javax.swing.SwingUtilities;

/**
 * @author cromer33
 * 
 */
public class DemoMain extends JApplet {

	private final class AppletGUIDoer implements Runnable {
		private String message;

		public AppletGUIDoer(String message) {
			super();
			this.setMessage(message);
		}

		public void run() {
			// add(new JLabel(message));
			add(new DemoTabs());
		}

		@SuppressWarnings("unused")
		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 2101834924305255893L;

	/**
	 * @param args
	 */
	@Override
	public void init() {
		super.init();
		try {
			SwingUtilities.invokeLater(new AppletGUIDoer("Hello World"));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
