package org.bjculk.demo;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MePanel extends JPanel {

	private final class MePanelInit implements Runnable {
		@Override
		public void run() {
			BorderLayout layout = new BorderLayout();
			String title = "<html><h1>About me. Now <u>with</u>&nbsp; <em>100%</em> more HTML!</h1></html>";
			layout.addLayoutComponent(new JLabel(title), BorderLayout.NORTH);
			setLayout(layout);
			add(new JLabel(title, JLabel.CENTER), BorderLayout.NORTH);

		}
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -6734929835839212910L;

	public MePanel() {
		super();
		SwingUtilities.invokeLater(new MePanelInit());
	}
}
